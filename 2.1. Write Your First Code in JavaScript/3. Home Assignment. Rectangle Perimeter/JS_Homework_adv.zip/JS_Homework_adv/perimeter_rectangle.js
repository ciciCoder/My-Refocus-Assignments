const length = 20
const width = 16

let perimeter = 2 * length + 2 * width

console.log(`Width: ${width}`)
console.log(`Length: ${length}`)
console.log(`Perimeter: ${perimeter}`)
