const length = 20
const width = 16

const area = length * width

console.log(`Width: ${width}`)
console.log(`Length: ${length}`)
console.log(`Perimeter: ${area}`)
